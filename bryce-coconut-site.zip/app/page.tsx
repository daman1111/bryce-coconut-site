export default function Home() {
  return (
    <main className="min-h-screen bg-green-100 text-gray-800">
      <section className="bg-green-500 text-white py-10 text-center">
        <h1 className="text-4xl font-bold">BRYCE</h1>
        <p className="text-xl mt-2">Coconut Peda - Pure Delight in Every Bite</p>
      </section>

      <section className="flex flex-col md:flex-row justify-center items-center gap-8 py-10 px-4">
        <img
          src="/IMG-20250218-WA0001.jpg"
          alt="Bryce Coconut Peda"
          className="w-full max-w-md rounded-xl shadow-lg"
        />
        <div className="bg-white p-6 rounded-xl shadow-lg max-w-md w-full">
          <h2 className="text-2xl font-semibold mb-4">Product Details</h2>
          <ul className="text-sm space-y-1">
            <li><strong>Price:</strong> ₹150</li>
            <li><strong>Product:</strong> Coconut Peda</li>
            <li><strong>Ingredients:</strong> Sugar, Liquid Glucose, Coconut Powder, Milk Powder, Coco Powder</li>
            <li><strong>Net Weight:</strong> 150 N</li>
            <li><strong>Manufactured by:</strong> Kathpal Trading Co., Malout, Punjab</li>
            <li><strong>Email:</strong> kathpaltradingco@gmail.com</li>
            <li><strong>Customer Care:</strong> 8847514695</li>
          </ul>
        </div>
      </section>

      <section className="text-center py-6">
        <p className="text-sm">© 2025 BRYCE. All rights reserved.</p>
      </section>
    </main>
  );
}